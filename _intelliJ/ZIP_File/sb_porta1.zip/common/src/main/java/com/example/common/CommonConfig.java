package com.example.common;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.example.common")
public class CommonConfig {
    // 공통 설정 클래스
} 