package com.example.controller;

import com.example.service.PersistenceContextDemoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/demo")
public class PersistenceContextDemoController {

    private final PersistenceContextDemoService demoService;

    public PersistenceContextDemoController(PersistenceContextDemoService demoService) {
        this.demoService = demoService;
    }

    @GetMapping("/persistence-context")
    public String showPersistenceContextDemo(Model model) {
        model.addAttribute("demoResult", demoService.demonstratePersistenceContext());
        return "persistence-context-demo";
    }

    @GetMapping("/team-member")
    public String showTeamMemberDemo(Model model) {
        model.addAttribute("demoResult", demoService.demonstrateTeamMemberRelationship());
        return "team-member-demo";
    }
} 