package com.example.service;

import com.example.entity.Member;
import com.example.entity.Team;
import com.example.repository.MemberRepository;
import com.example.repository.TeamRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
public class PersistenceContextDemoService {

    @PersistenceContext
    private EntityManager entityManager;

    private final MemberRepository memberRepository;
    private final TeamRepository teamRepository;

    public PersistenceContextDemoService(MemberRepository memberRepository, TeamRepository teamRepository) {
        this.memberRepository = memberRepository;
        this.teamRepository = teamRepository;
    }

    @Transactional
    public Map<String, Object> demonstratePersistenceContext() {
        Map<String, Object> result = new HashMap<>();
        
        // 1. 새로운 엔티티 생성 (New 상태)
        Member member = new Member();
        member.setName("홍길동");
        member.setEmail("hong@example.com");
        
        // 2. 엔티티 저장 (Managed 상태로 변경)
        memberRepository.save(member);
        
        // 3. 영속성 컨텍스트 상태 확인
        result.put("memberStatus", "Managed");
        result.put("memberId", member.getId());
        
        // 4. 엔티티 수정 (Dirty 상태)
        member.setName("홍길동 수정");
        result.put("memberName", member.getName());
        
        // 5. 영속성 컨텍스트 초기화
        entityManager.clear();
        result.put("contextCleared", true);
        
        // 6. 엔티티 다시 조회
        Member foundMember = memberRepository.findById(member.getId()).orElse(null);
        result.put("foundMember", foundMember);
        
        return result;
    }

    @Transactional
    public Map<String, Object> demonstrateTeamMemberRelationship() {
        Map<String, Object> result = new HashMap<>();
        
        // 1. 팀 생성
        Team team = new Team();
        team.setName("개발팀");
        teamRepository.save(team);
        
        // 2. 멤버 생성 및 팀에 추가
        Member member1 = new Member();
        member1.setName("김철수");
        member1.setEmail("kim@example.com");
        member1.setTeam(team);
        memberRepository.save(member1);
        
        Member member2 = new Member();
        member2.setName("이영희");
        member2.setEmail("lee@example.com");
        member2.setTeam(team);
        memberRepository.save(member2);
        
        // 3. 팀에 멤버 추가
        team.getMembers().add(member1);
        team.getMembers().add(member2);
        
        result.put("team", team);
        result.put("members", team.getMembers());
        
        return result;
    }
} 