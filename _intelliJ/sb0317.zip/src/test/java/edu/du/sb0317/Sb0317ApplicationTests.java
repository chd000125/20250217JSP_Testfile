package edu.du.sb0317;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb0317ApplicationTests {

    @Test
    void contextLoads() {
    }

}
