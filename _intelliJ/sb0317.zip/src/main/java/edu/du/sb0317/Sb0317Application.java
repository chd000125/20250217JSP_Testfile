package edu.du.sb0317;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb0317Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb0317Application.class, args);
    }

}
