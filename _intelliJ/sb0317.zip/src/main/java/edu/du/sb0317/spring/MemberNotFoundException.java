package edu.du.sb0317.spring;

public class MemberNotFoundException extends RuntimeException {

}
