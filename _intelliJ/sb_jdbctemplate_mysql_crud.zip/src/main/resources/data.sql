INSERT INTO users (name, email, phone) VALUES
('홍길동', 'hong@example.com', '010-1234-5678'),
('김철수', 'kim@example.com', '010-2345-6789'),
('이영희', 'lee@example.com', '010-3456-7890'),
('박민수', 'park@example.com', '010-4567-8901'),
('정수진', 'jung@example.com', '010-5678-9012'); 